/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int valley(long int steps, char *path) {
    long int level,i,vcount=0;
    for(i=0;i<steps;i++){
        if(path[i]=='U'){
            level++;
        }else if(path[i]=='D')
        {
            if(level==1){
                vcount++;
            }
            level--;
        }
        
    }
    return vcount;
}
int main()
{
    long int steps;
    scanf("%li",&steps);
    char path[steps];
    int i,result;
    for(i=0;i<steps;i++){
        scanf("%c",&path[i]);
    }
    result=valley(steps,path);
    printf("%d",result);
    return 0;
}
